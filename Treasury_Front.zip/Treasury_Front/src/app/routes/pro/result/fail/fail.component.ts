import { Component } from '@angular/core';

@Component({
  selector: 'app-result-fail',
  templateUrl: './fail.component.html',
})
export class ProResultFailComponent {}
