import { Component } from '@angular/core';

@Component({
  selector: 'app-gridmasonry',
  templateUrl: './gridmasonry.component.html',
  styleUrls: ['./gridmasonry.component.less'],
})
export class GridMasonryComponent {}
